<?php


/**
 * CurlException
 *
 * @author Arsene Tochemey GANDOTE
 *
 */
class CurlException extends Exception{
}
